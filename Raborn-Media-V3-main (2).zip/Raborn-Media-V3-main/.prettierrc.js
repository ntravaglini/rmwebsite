module.exports = require( '@wordpress/prettier-config' );

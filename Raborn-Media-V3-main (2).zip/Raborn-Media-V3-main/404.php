<?php
/**
 * The template for displaying 404 pages (not found).
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package Raborn Media
 */

get_header(); ?>

	<main id="main" class="container site-main">

		<section class="error-404 not-found">

			<div class="message">

				<img src="https://rabornmedianew.pntmsip1-liquidwebsites.com/wp-content/uploads/2021/12/404Img.png">

				<h4>
					<?php esc_html_e( "Sorry, it seems we can’t find what you’re looking for or this page doesn’t exist.", 'rm' ); ?>
				</h4>

				<a class="wp-block-button__link has-white-color has-blue-dark-background-color has-text-color has-background" href="/"> Back to Home </a>

			</div>

		</section><!-- .error-404 -->

	</main><!-- #main -->

<?php get_footer(); ?>

<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Raborn Media
 */

?>

	<footer class="site-footer">
		<div class="container flex flex-wrap">
			<div class="footer-left wp-admin-bar:w-9/12 wp-admin-bar:pr-56">
				<div class="contact">
					<div class="lets-chat grid-cols-2">
						<?php echo do_shortcode( rm_display_footer_logo() ); ?>
						<div>
							<h2 class="h4 mb-10"><?php rm_display_phone_header(); ?></h2>
							<a class="text-lg no-underline italic" href="tel:<?php rm_display_phone(); ?>"><?php rm_display_phone(); ?></a>
						</div>
						<!-- <h2 class="h3">Let's Chat: <span><?php rm_display_email(); ?></span></h2> -->
					</div>
					<!-- <div class="number">
					</div> -->
				</div>
			</div>
			<div class="footer-right w-full wp-admin-bar:w-3/12">
				<?php dynamic_sidebar( 'footer' ); ?>
			</div>
		</div>
		<div class="footer-bottom container flex flex-wrap">
			<div class="wp-admin-bar:w-6/12 pr-32 w-full">
				<div class="social-links">
					<?php rm_display_social_network_links(); ?>
				</div>
				<div class="site-info">
					<?php rm_display_copyright_text(); ?>
				</div><!-- .site-info -->
			</div>
			<div class="wp-admin-bar:w-6/12">
				<?php rm_display_footer_menu(); ?>
			</div>
		</div>

	</footer><!-- .site-footer container-->

	<?php rm_display_mobile_menu(); ?>
	<?php wp_footer(); ?>

</body>

</html>

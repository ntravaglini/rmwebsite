<?php
/**
 * The template for the homepage.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package Raborn Media
 */

get_header(); ?>

	<main id="main" class="page-main">

		<?php
			get_template_part( 'template-parts/partials/home-hero' );
			get_template_part( 'template-parts/partials/home-brands' );
			get_template_part( 'template-parts/partials/home-testimonials' );
		?>

		<?php
			get_template_part( 'template-parts/content-page' );
		?>

	</main><!-- #main -->

<?php get_footer(); ?>

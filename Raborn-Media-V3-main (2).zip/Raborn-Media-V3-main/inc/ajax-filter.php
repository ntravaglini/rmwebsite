<?php
/**
 * Ajax Filter.
 *
 * This file is used to house "getter" function, that fetch data from the database.
 *
 * @package Raborn Media
 */

/**
 * Ajax Filter.
 *
 * Depending on the categories and tags a user selects via ACF, build the query args.
 *
 * @author RM
 */
function rm_portfolio_filter_ajax() {
	$terms  = $_POST['type']; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- XSS OK.
	$tax    = $_POST['tax']; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- XSS OK.
	$offset = $_POST['offset']; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- XSS OK.

	if ( 'all' !== $tax ) {
		$args = array(
			'offset'    => $offset,
			'tax_query' => array(
				array(
					'taxonomy'         => $terms,
					'field'            => 'slug',
					'terms'            => $tax,
					'include_children' => false,

				),
			),
		);
	} else {
		$args = array(
			'offset'      => $offset,
			'post_parent' => 0,
		);
	}

	$result = array(
		'test'       => $offset,
		'query'      => rm_portfolio_loop( $args ),
		'post_found' => rm_portfolio_posts( $args )->found_posts,
	);
	wp_send_json( $result );
	die();
}


add_action( 'wp_ajax_nopriv_port_filter', 'rm_portfolio_filter_ajax' );
add_action( 'wp_ajax_port_filter', 'rm_portfolio_filter_ajax' );

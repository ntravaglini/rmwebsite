<?php
/**
 * Customizer settings.
 *
 * @package Raborn Media
 */

/**
 * Register additional scripts.
 *
 * @author WebDevStudios
 *
 * @param WP_Customize_Manager $wp_customize Instance of WP_Customize_Manager.
 */
function rm_customize_additional_scripts( $wp_customize ) {
	// Register a setting.
	$wp_customize->add_setting(
		'rm_header_scripts',
		[
			'default'           => '',
			'sanitize_callback' => 'force_balance_tags',
		]
	);

	// Create the setting field.
	$wp_customize->add_control(
		'rm_header_scripts',
		[
			'label'       => esc_attr__( 'Header Scripts', 'rm' ),
			'description' => esc_attr__( 'Additional scripts to add to the header. Basic HTML tags are allowed.', 'rm' ),
			'section'     => 'rm_additional_scripts_section',
			'type'        => 'textarea',
		]
	);

	// Register a setting.
	$wp_customize->add_setting(
		'rm_footer_scripts',
		[
			'default'           => '',
			'sanitize_callback' => 'force_balance_tags',
		]
	);

	// Create the setting field.
	$wp_customize->add_control(
		'rm_footer_scripts',
		[
			'label'       => esc_attr__( 'Footer Scripts', 'rm' ),
			'description' => esc_attr__( 'Additional scripts to add to the footer. Basic HTML tags are allowed.', 'rm' ),
			'section'     => 'rm_additional_scripts_section',
			'type'        => 'textarea',
		]
	);
}

add_action( 'customize_register', 'rm_customize_additional_scripts' );


/**
 * Register a social icons setting.
 *
 * @author WebDevStudios
 *
 * @param WP_Customize_Manager $wp_customize Instance of WP_Customize_Manager.
 */
function rm_customize_social_icons( $wp_customize ) {
	// Create an array of our social links for ease of setup.
	$social_networks = [
		'instagram',
		'twitter',
		'facebook',
		'linkedin',
		'youtube',
		'vimeo',
	];

	// Loop through our networks to setup our fields.
	foreach ( $social_networks as $network ) {

		// Register a setting.
		$wp_customize->add_setting(
			'rm_' . $network . '_link',
			[
				'default'           => '',
				'sanitize_callback' => 'esc_url',
			]
		);

		// Create the setting field.
		$wp_customize->add_control(
			'rm_' . $network . '_link',
			[
				'label'   => /* translators: the social network name. */ sprintf( esc_attr__( '%s URL', 'rm' ), ucwords( $network ) ),
				'section' => 'rm_social_links_section',
				'type'    => 'text',
			]
		);
	}
}

add_action( 'customize_register', 'rm_customize_social_icons' );


/**
 * Register footer logo.
 *
 * @author RM
 * @param object $wp_customize Instance of WP_Customize_Class.
 */
function rm_footer_logo( $wp_customize ) {
	// Register a setting.
	$wp_customize->add_setting(
		'rm_footer_logo',
		array(
			'default'           => '',
			'sanitize_callback' => 'wp_kses_post',
		)
	);

	// Create the setting field.
	$wp_customize->add_control(
		new WP_Customize_Image_Control(
			$wp_customize,
			'rm_footer_logo',
			array(
				'label'    => esc_html__( 'Footer Logo', 'rm' ),
				'section'  => 'rm_footer_section',
				'type'     => 'image',
				'priority' => 8,
			)
		)
	);
}
add_action( 'customize_register', 'rm_footer_logo' );

/**
 * Register email.
 *
 * @author RabornMedia
 *
 * @param WP_Customize_Manager $wp_customize Instance of WP_Customize_Manager.
 */
function rm_customize_email( $wp_customize ) {
	// Register a setting.
	$wp_customize->add_setting(
		'rm_email',
		[
			'default'           => '',
			'sanitize_callback' => 'wp_kses_post',
		]
	);

	// Create the setting field.
	$wp_customize->add_control(
		'rm_email',
		[
			'label'       => esc_attr__( 'Contact Email', 'rm' ),
			'description' => esc_attr__( 'Add contact email here.', 'rm' ),
			'section'     => 'rm_footer_section',
			'type'        => 'text',
		]
	);
}

add_action( 'customize_register', 'rm_customize_email' );

/**
 * Register phone.
 *
 * @author RabornMedia
 *
 * @param WP_Customize_Manager $wp_customize Instance of WP_Customize_Manager.
 */
function rm_customize_phone( $wp_customize ) {
	// Register a setting.
	$wp_customize->add_setting(
		'rm_phone_header',
		[
			'default'           => '',
			'sanitize_callback' => 'wp_kses_post',
		]
	);

	// Register a setting.
	$wp_customize->add_setting(
		'rm_phone',
		[
			'default'           => '',
			'sanitize_callback' => 'wp_kses_post',
		]
	);

	// Create the setting field.
	$wp_customize->add_control(
		'rm_phone_header',
		[
			'label'   => esc_attr__( 'Contact Number Header', 'rm' ),
			'section' => 'rm_footer_section',
			'type'    => 'text',
		]
	);

	// Create the setting field.
	$wp_customize->add_control(
		'rm_phone',
		[
			'label'       => esc_attr__( 'Contact Phone', 'rm' ),
			'description' => esc_attr__( 'Add contact phone here.', 'rm' ),
			'section'     => 'rm_footer_section',
			'type'        => 'text',
		]
	);
}

add_action( 'customize_register', 'rm_customize_phone' );

/**
 * Register copyright text setting.
 *
 * @author WebDevStudios
 *
 * @param WP_Customize_Manager $wp_customize Instance of WP_Customize_Manager.
 */
function rm_customize_copyright_text( $wp_customize ) {
	// Register a setting.
	$wp_customize->add_setting(
		'rm_copyright_text',
		[
			'default'           => '',
			'sanitize_callback' => 'wp_kses_post',
		]
	);

	// Create the setting field.
	$wp_customize->add_control(
		new Text_Editor_Custom_Control(
			$wp_customize,
			'rm_copyright_text',
			[
				'label'       => esc_attr__( 'Copyright Text', 'rm' ),
				'description' => esc_attr__( 'The copyright text will be displayed in the footer. Basic HTML tags allowed.', 'rm' ),
				'section'     => 'rm_footer_section',
				'type'        => 'textarea',
			]
		)
	);
}

add_action( 'customize_register', 'rm_customize_copyright_text' );

<?php
/**
 * Custom scripts and styles.
 *
 * @package Raborn Media
 */

/**
 * Enqueue scripts and styles.
 *
 * @author WebDevStudios
 */
function rm_scripts() {
	$asset_file_path = dirname( __DIR__ ) . '/build/index.asset.php';

	if ( is_readable( $asset_file_path ) ) {
		$asset_file = include $asset_file_path;
	} else {
		$asset_file = [
			'version'      => '1.0.0',
			'dependencies' => [ 'wp-polyfill' ],
		];
	}

	// Register styles & scripts.
	wp_enqueue_style( 'wd_s', get_stylesheet_directory_uri() . '/build/index.css', [], $asset_file['version'] );
	wp_enqueue_script( 'gsap', 'https://cdnjs.cloudflare.com/ajax/libs/gsap/3.7.0/gsap.min.js', $asset_file['dependencies'], '3.7.0', true, true );
	wp_enqueue_script( 'wds-scripts', get_stylesheet_directory_uri() . '/build/index.js', array( 'jquery', 'wp-polyfill' ), $asset_file['version'], true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}

	wp_localize_script(
		'wds-scripts',
		'wp_ajax',
		[
			'ajax_url'      => admin_url( 'admin-ajax.php' ),
			'nonce'         => wp_create_nonce( 'nonce_filter' ),
			'course_number' => rm_number_of_posts(),
		]
	);
}

add_action( 'wp_enqueue_scripts', 'rm_scripts' );

/**
 * Enqueue admin scripts and styles.
 *
 * @author Raborn Media
 */
function rm_admin_scripts() {

	wp_enqueue_script( 'rm-editor-scripts', get_stylesheet_directory_uri() . '/build/editor.js', $asset_file['dependencies'], $asset_file['version'], true );

}

add_action( 'admin_enqueue_scripts', 'rm_admin_scripts' );

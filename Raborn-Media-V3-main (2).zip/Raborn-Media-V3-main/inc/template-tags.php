<?php
/**
 * Custom template tags for this theme.
 *
 * Eventually, some of the functionality here could be replaced by core features.
 *
 * @package Raborn Media
 */

/**
 * Prints HTML with meta information for the current post-date/time and author.
 *
 * @author WebDevStudios
 */
function rm_posted_on() {
	$time_string = '<time class="entry-date published updated" datetime="%1$s">%2$s</time>';
	if ( get_the_time( 'U' ) !== get_the_modified_time( 'U' ) ) {
		$time_string = '<time class="entry-date published" datetime="%1$s">%2$s</time><time class="updated" datetime="%3$s">%4$s</time>';
	}

	$time_string = sprintf(
		$time_string,
		esc_attr( get_the_date( DATE_W3C ) ),
		esc_html( get_the_date() ),
		esc_attr( get_the_modified_date( DATE_W3C ) ),
		esc_html( get_the_modified_date() )
	);

	$posted_on = sprintf(
		/* translators: the date the post was published */
		esc_html_x( 'Posted on %s', 'post date', 'rm' ),
		'<a href="' . esc_url( get_permalink() ) . '" rel="bookmark">' . $time_string . '</a>'
	);

	$byline = sprintf(
		/* translators: the post author */
		esc_html_x( 'by %s', 'post author', 'rm' ),
		'<span class="author vcard"><a class="url fn n" href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '">' . esc_html( get_the_author() ) . '</a></span>'
	);

	 // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- XSS OK.
	echo '<span class="posted-on">' . $posted_on . '</span><span class="byline"> ' . $byline . '</span>';
}

/**
 * Prints HTML with meta information for the categories, tags and comments.
 *
 * @author WebDevStudios
 */
function rm_entry_footer() {
	// Hide category and tag text for pages.
	if ( 'post' === get_post_type() ) {
		/* translators: used between list items, there is a space after the comma */
		$categories_list = get_the_category_list( esc_attr__( ', ', 'rm' ) );
		if ( $categories_list && rm_categorized_blog() ) {

			/* translators: the post category */
			printf( '<span class="cat-links">' . esc_attr__( 'Posted in %1$s', 'rm' ) . '</span>', $categories_list ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- XSS OK.
		}

		/* translators: used between list items, there is a space after the comma */
		$tags_list = get_the_tag_list( '', esc_attr__( ', ', 'rm' ) );
		if ( $tags_list ) {

			/* translators: the post tags */
			printf( '<span class="tags-links">' . esc_attr__( 'Tagged %1$s', 'rm' ) . '</span>', $tags_list ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- XSS OK.
		}
	}

	if ( ! is_single() && ! post_password_required() && ( comments_open() || get_comments_number() ) ) {
		echo '<span class="comments-link">';
		comments_popup_link( esc_attr__( 'Leave a comment', 'rm' ), esc_attr__( '1 Comment', 'rm' ), esc_attr__( '% Comments', 'rm' ) );
		echo '</span>';
	}

	edit_post_link(
		sprintf(
			/* translators: %s: Name of current post */
			esc_html__( 'Edit %s', 'rm' ),
			wp_kses_post( get_the_title( '<span class="screen-reader-text">"', '"</span>', false ) )
		),
		'<span class="edit-link">',
		'</span>'
	);
}

/**
 * Display SVG Markup.
 *
 * @author WebDevStudios
 *
 * @param array $args The parameters needed to get the SVG.
 */
function rm_display_svg( $args = [] ) {
	$kses_defaults = wp_kses_allowed_html( 'post' );

	$svg_args = [
		'svg'   => [
			'class'           => true,
			'aria-hidden'     => true,
			'aria-labelledby' => true,
			'role'            => true,
			'xmlns'           => true,
			'width'           => true,
			'height'          => true,
			'viewbox'         => true, // <= Must be lower case!
			'color'           => true,
			'stroke-width'    => true,
		],
		'g'     => [ 'color' => true ],
		'title' => [
			'title' => true,
			'id'    => true,
		],
		'path'  => [
			'd'     => true,
			'color' => true,
		],
		'use'   => [
			'xlink:href' => true,
		],
	];

	$allowed_tags = array_merge(
		$kses_defaults,
		$svg_args
	);

	echo wp_kses(
		rm_get_svg( $args ),
		$allowed_tags
	);
}

/**
 * Return SVG markup.
 *
 * @author WebDevStudios
 *
 * @param array $args The parameters needed to display the SVG.
 *
 * @return string Error string or SVG markup.
 */
function rm_get_svg( $args = [] ) {
	// Make sure $args are an array.
	if ( empty( $args ) ) {
		return esc_attr__( 'Please define default parameters in the form of an array.', 'rm' );
	}

	// Define an icon.
	if ( false === array_key_exists( 'icon', $args ) ) {
		return esc_attr__( 'Please define an SVG icon filename.', 'rm' );
	}

	// Set defaults.
	$defaults = [
		'color'        => '',
		'icon'         => '',
		'title'        => '',
		'desc'         => '',
		'stroke-width' => '',
		'height'       => '',
		'width'        => '',
	];

	// Parse args.
	$args = wp_parse_args( $args, $defaults );

	// Figure out which title to use.
	$block_title = ( $args['title'] ) ? $args['title'] : $args['icon'];

	// Generate random IDs for the title and description.
	$random_number  = wp_rand( 0, 99999 );
	$block_title_id = 'title-' . sanitize_title( $block_title ) . '-' . $random_number;
	$desc_id        = 'desc-' . sanitize_title( $block_title ) . '-' . $random_number;

	// Set ARIA.
	$aria_hidden     = ' aria-hidden="true"';
	$aria_labelledby = '';

	if ( $args['title'] && $args['desc'] ) {
		$aria_labelledby = ' aria-labelledby="' . $block_title_id . ' ' . $desc_id . '"';
		$aria_hidden     = '';
	}

	// Set SVG parameters.
	$color        = ( $args['color'] ) ? ' color="' . $args['color'] . '"' : '';
	$stroke_width = ( $args['stroke-width'] ) ? ' stroke-width="' . $args['stroke-width'] . '"' : '';
	$height       = ( $args['height'] ) ? ' height="' . $args['height'] . '"' : '';
	$width        = ( $args['width'] ) ? ' width="' . $args['width'] . '"' : '';

	// Start a buffer...
	ob_start();
	?>

	<svg
	<?php
		echo rm_get_the_content( $height ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- XSS OK.
		echo rm_get_the_content( $width ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- XSS OK.
		echo rm_get_the_content( $color ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- XSS OK.
		echo rm_get_the_content( $stroke_width ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- XSS OK.
	?>
		class="icon <?php echo esc_attr( $args['icon'] ); ?>"
	<?php
		echo rm_get_the_content( $aria_hidden ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- XSS OK.
		echo rm_get_the_content( $aria_labelledby ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- XSS OK.
	?>
		role="img">
		<title id="<?php echo esc_attr( $block_title_id ); ?>">
			<?php echo esc_html( $block_title ); ?>
		</title>

		<?php
		// Display description if available.
		if ( $args['desc'] ) :
			?>
			<desc id="<?php echo esc_attr( $desc_id ); ?>">
				<?php echo esc_html( $args['desc'] ); ?>
			</desc>
		<?php endif; ?>

		<?php
		// Use absolute path in the Customizer so that icons show up in there.
		if ( is_customize_preview() ) :
			?>
			<use xlink:href="<?php echo esc_url( get_parent_theme_file_uri( '/build/images/icons/sprite.svg#' . esc_html( $args['icon'] ) ) ); ?>"></use>
		<?php else : ?>
			<use xlink:href="#<?php echo esc_html( $args['icon'] ); ?>"></use>
		<?php endif; ?>

	</svg>

	<?php
	// Get the buffer and return.
	return ob_get_clean();
}

/**
 * Trim the title length.
 *
 * @author WebDevStudios
 *
 * @param array $args Parameters include length and more.
 *
 * @return string The title.
 */
function rm_get_the_title( $args = [] ) {
	// Set defaults.
	$defaults = [
		'length' => 12,
		'more'   => '...',
	];

	// Parse args.
	$args = wp_parse_args( $args, $defaults );

	// Trim the title.
	return wp_kses_post( wp_trim_words( get_the_title( get_the_ID() ), $args['length'], $args['more'] ) );
}

/**
 * Limit the excerpt length.
 *
 * @author WebDevStudios
 *
 * @param array $args Parameters include length and more.
 *
 * @return string The excerpt.
 */
function rm_get_the_excerpt( $args = [] ) {

	// Set defaults.
	$defaults = [
		'length' => 20,
		'more'   => '...',
		'post'   => '',
	];

	// Parse args.
	$args = wp_parse_args( $args, $defaults );

	// Trim the excerpt.
	return wp_trim_words( get_the_excerpt( $args['post'] ), absint( $args['length'] ), esc_html( $args['more'] ) );
}

/**
 * Display the footer logo.
 *
 * @author RM
 */
function rm_display_footer_logo() {

	$logo_url = get_theme_mod( 'rm_footer_logo' );
	$logo_id  = rm_get_attachment_id_from_url( $logo_url );

	return wp_get_attachment_image( $logo_id, 'full' );

}

/**
 * Echo the phone number text saved in the Customizer.
 *
 * @author WebDevStudios
 */
function rm_display_phone_header() {
	// Grab our customizer settings.
	$text = get_theme_mod( 'rm_phone_header' );

	if ( $text ) {
		echo rm_get_the_content( do_shortcode( $text ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- XSS OK.
	}
}

/**
 * Echo the phone number text saved in the Customizer.
 *
 * @author WebDevStudios
 */
function rm_display_phone() {
	// Grab our customizer settings.
	$text = get_theme_mod( 'rm_phone' );

	if ( $text ) {
		echo rm_get_the_content( do_shortcode( $text ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- XSS OK.
	}
}

/**
 * Echo the email text saved in the Customizer.
 *
 * @author WebDevStudios
 */
function rm_display_email() {
	// Grab our customizer settings.
	$text = get_theme_mod( 'rm_email' );

	if ( $text ) {
		echo '<a href="mailto:' . rm_get_the_content( do_shortcode( $text ) ) . '">' . rm_get_the_content( do_shortcode( $text ) ) . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- XSS OK.
	}
}

/**
 * Echo the copyright text saved in the Customizer.
 *
 * @author WebDevStudios
 */
function rm_display_copyright_text() {
	// Grab our customizer settings.
	$copyright_text = get_theme_mod( 'rm_copyright_text' );

	if ( $copyright_text ) {
		echo rm_get_the_content( do_shortcode( $copyright_text ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- XSS OK.
	}
}

/**
 * Display the social links saved in the customizer.
 *
 * @author WebDevStudios
 */
function rm_display_social_network_links() {
	// Create an array of our social links for ease of setup.
	// Change the order of the networks in this array to change the output order.
	$social_networks = [
		'instagram',
		'twitter',
		'facebook',
		'linkedin',
		'youtube',
		'vimeo',
	];

	?>
	<ul class="flex social-icons menu">
		<?php
		// Loop through our network array.
		foreach ( $social_networks as $network ) :

			// Look for the social network's URL.
			$network_url = get_theme_mod( 'rm_' . $network . '_link' );

			// Only display the list item if a URL is set.
			if ( ! empty( $network_url ) ) :
				?>
				<li class="social-icon <?php echo esc_attr( $network ); ?> mr-24">
					<a href="<?php echo esc_url( $network_url ); ?>">
						<?php
						rm_display_svg(
							[
								'icon'   => $network . '-square',
								'width'  => '28',
								'height' => '28',
							]
						);
						?>
						<span class="screen-reader-text">
						<?php
						/* translators: the social network name */
						printf( esc_attr__( 'Link to %s', 'rm' ), ucwords( esc_html( $network ) ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- XSS OK.
						?>
						</span>
					</a>
				</li><!-- .social-icon -->
				<?php
			endif;
		endforeach;
		?>
	</ul><!-- .social-icons -->
	<?php
}

/**
 * Displays numeric pagination on archive pages.
 *
 * @author WebDevStudios
 *
 * @param array    $args  Array of params to customize output.
 * @param WP_Query $query The Query object; only passed if a custom WP_Query is used.
 */
function rm_display_numeric_pagination( $args = [], $query = null ) {
	if ( ! $query ) {
		global $wp_query;
		$query = $wp_query;
	}

	// Make the pagination work on custom query loops.
	$total_pages = isset( $query->max_num_pages ) ? $query->max_num_pages : 1;

	// Set defaults.
	$defaults = [
		'prev_text' => '&laquo;',
		'next_text' => '&raquo;',
		'mid_size'  => 4,
		'total'     => $total_pages,
	];

	// Parse args.
	$args = wp_parse_args( $args, $defaults );

	if ( null === paginate_links( $args ) ) {
		return;
	}
	?>

	<nav class="container pagination-container" aria-label="<?php esc_attr_e( 'numeric pagination', 'rm' ); ?>">
		<?php echo paginate_links( $args ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- XSS OK. ?>
	</nav>

	<?php
}

/**
 * Displays the mobile menu with off-canvas background layer.
 *
 * @author WebDevStudios
 *
 * @return string An empty string if no menus are found at all.
 */
function rm_display_mobile_menu() {
	// Bail if no mobile or primary menus are set.
	if ( ! has_nav_menu( 'mobile' ) && ! has_nav_menu( 'primary' ) ) {
		return '';
	}

	// Set a default menu location.
	$menu_location = 'primary';

	// If we have a mobile menu explicitly set, use it.
	if ( has_nav_menu( 'mobile' ) ) {
		$menu_location = 'mobile';
	}
	?>
	<div class="off-canvas-screen"></div>
	<nav class="off-canvas-container" aria-label="<?php esc_attr_e( 'Mobile Menu', 'rm' ); ?>" aria-hidden="true" tabindex="-1">
		<?php
		// Mobile menu args.
		$mobile_args = [
			'theme_location'  => $menu_location,
			'container'       => 'div',
			'container_class' => 'off-canvas-content',
			'container_id'    => '',
			'menu_id'         => 'site-mobile-menu',
			'menu_class'      => 'mobile-menu',
			'fallback_cb'     => false,
			'items_wrap'      => '<ul id="%1$s" class="%2$s">%3$s</ul>',
		];

		// Display the mobile menu.
		wp_nav_menu( $mobile_args );
		?>
		<div class="social-icons off-canvas-content">
			<?php rm_display_social_network_links(); ?>
		</div>
	</nav>

	<?php
}

/**
 * Display the footer menu.
 *
 * @author Kelsey
 */
function rm_display_footer_menu() {

	if ( has_nav_menu( 'footer' ) ) {
		?>
	<nav id="footer-navigation" class="footer-navigation" aria-label="<?php esc_attr_e( 'Footer Navigation', 'rm' ); ?>">
		<?php
		wp_nav_menu(
			[
				'fallback_cb'    => false,
				'theme_location' => 'footer',
				'menu_id'        => 'footer-menu',
				'menu_class'     => 'menu',
				'container'      => false,
			]
		);
		?>
	</nav><!-- #site-navigation-->

		<?php
	} else {
		return;
	}
}

/**
 * Display the comments if the count is more than 0.
 *
 * @author WebDevStudios
 */
function rm_display_comments() {
	if ( comments_open() || get_comments_number() ) {
		comments_template();
	}
}


/**
 * Get svg from svg folder.
 *
 * @param string $svg name of svg file.
 * @author Kelsey
 */
function rm_get_custom_svg( $svg ) {

	$arr_context_options = array(
		'ssl' => array(
			'verify_peer'      => false,
			'verify_peer_name' => false,
		),
	);

	return file_get_contents( get_stylesheet_directory_uri() . '/build/images/svg/' . $svg . '.svg', false, stream_context_create( $arr_context_options ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- XSS OK.
}

/**
 * Our callback function – this looks for the block based on its given name.
 * Name accordingly to the file name!
 *
 * @param array $block The block details.
 * @author Corey Collins
 * @since 1.0
 */
function rm_acf_blocks_acf_block_registration_callback( $block ) {

	// Convert the block name into a handy slug.
	$block_slug = str_replace( 'acf/', '', $block['name'] );

	// Include our template part.
	if ( file_exists( plugin_dir_path( dirname( __FILE__ ) ) . 'template-parts/blocks/block-' . $block_slug . '.php' ) ) {
		include plugin_dir_path( dirname( __FILE__ ) ) . 'template-parts/blocks/block-' . $block_slug . '.php';
	}
}

/**
 * Returns the alignment set for a content block.
 *
 * @param array $block The block settings.
 * @return string The class, if one is set.
 * @author Corey Collins
 * @since 1.0
 */
function rm_get_block_alignment( $block ) {

	if ( ! $block ) {
		return;
	}

	return ! empty( $block['align'] ) ? ' align' . esc_attr( $block['align'] ) : 'alignwide';
}

/**
 * Returns the class names set for a content block.
 *
 * @param array $block The block settings.
 * @return string The class, if one is set.
 * @author Corey Collins
 * @since 1.0
 */
function rm_get_block_classes( $block ) {

	if ( ! $block ) {
		return;
	}

	$classes  = '';
	$classes .= ! empty( $block['className'] ) ? ' ' . esc_attr( $block['className'] ) : '';

	return $classes;
}

/**
 * Get services query.
 *
 * @param string $post_type which service post type to query.
 * @return object The related posts object.
 * @author RM
 */
function rm_get_services_query( $post_type ) {

	// Setup default WP_Query args.
	$args = array(
		'orderby'        => 'menu_order',
		'order'          => 'ASC',
		'posts_per_page' => -1,
		'post_type'      => $post_type,
		'post_parent'    => 0,
	);

	// Run the query!
	$services = new WP_Query( $args );

	return $services;
}


/**
 * Get services sub-page query.
 *
 * @param array $args for query.
 * @return object The related posts object.
 * @author RM
 */
function rm_get_services_subpages( $args = array() ) {

	// Setup default WP_Query args.
	$defaults = array(
		'orderby'        => 'menu_order',
		'order'          => 'ASC',
		'posts_per_page' => -1,
		'post_parent'    => '',
		'post_type'      => '',
	);

	// Parse args.
	$args = wp_parse_args( $args, $defaults );

	// Run the query!
	$services = new WP_Query( $args );

	return $services;
}

/**
 * Display tag list
 *
 * @author  Kelsey
 * @param  array $query for the tags.
 */
function rm_tag_list( $query = array() ) {

	if ( $query->have_posts() ) :
		?>
	<ul class="tag-list">
		<?php
		while ( $query->have_posts() ) :
			$query->the_post();
			?>
			<li class="tag">
				<a href="<?php echo esc_url( get_the_permalink() ); ?>"><?php echo esc_html( get_the_title() ); ?></a>
			</li>
			<?php
		endwhile;
		wp_reset_postdata();
		?>
	</ul>
		<?php
	endif;
}


/**
 * Display a services Card.
 *
 * @author Kelsey
 * @param array $args Card defaults.
 * @since 1.0
 */
function rm_display_services_card( $args = array() ) {

	// Setup defaults.
	$defaults = array(
		'title' => '',
		'image' => '',
		'text'  => '',
		'url'   => '',
		'ID'    => '',
		'type'  => '',
	);

	$icon = get_field( 'icon', $args['ID'] );

	$sub_pages_args = array(
		'post_type'   => $args['type'],
		'post_parent' => $args['ID'],
	);

	$sub_pages = rm_get_services_subpages( $sub_pages_args );

	// Parse args.
	$args = wp_parse_args( $args, $defaults );
	?>
	<div class="services-card card">
		<div class="card-img col">
			<?php if ( $args['image'] ) : ?>
				<div class="img-wrapper">
					<?php echo wp_kses_post( $args['image'] ); ?>
				</div>
			<?php endif; ?>
		</div>
		<div class="card-content col">
			<div class="card-top">
				<div class="card-title-wrapper">
					<?php
					if ( $icon['id'] ) {
						echo wp_get_attachment_image( $icon['id'], 'full' );
					}
					?>
					<h3 class="card-title"><?php echo esc_html( $args['title'] ); ?></h3>
				</div>
				<?php if ( $args['excerpt'] ) : ?>
					<p class="excerpt">
						<?php echo do_shortcode( $args['excerpt'] ); ?>
					</p>
				<?php endif; ?>
				<a href="<?php echo esc_url( $args['url'] ); ?>" class="button">Learn More</a>
			</div>
			<?php if ( $sub_pages->have_posts() ) : ?>
				<div class="card-footer">
					<?php rm_tag_list( $sub_pages ); ?>
				</div>
			<?php endif; ?>
		</div>
	</div>
		<?php
}

/**
 * Display a project card.
 *
 * @author Kelsey
 * @param array $args Card defaults.
 * @since 1.0
 */
function rm_display_project_card( $args = array() ) {

	global $post;

	// Setup defaults.
	$defaults = array(
		'title'  => '',
		'image'  => '',
		'text'   => '',
		'url'    => '',
		'ID'     => '',
		'client' => '',
	);

	// Parse args.
	$args = wp_parse_args( $args, $defaults );

	$tags = wp_get_post_terms( $post->ID, array( 'skills', 'industries', 'services' ) );

	$this_client_slug = 'client_' . rm_display_client()->term_id;
	$client_color     = get_field( 'client_color', $this_client_slug );

	?>

	<div class="project-card card col-3" style="background-color: <?php echo esc_attr( $client_color ); ?>;">
		<div class="card-img">
			<?php if ( $args['image'] ) : ?>
				<a href="<?php echo esc_url( $args['url'] ); ?>" tabindex="-1" class="img-wrapper" style="background-color: <?php echo esc_attr( $client_color ); ?>;">
					<?php echo wp_kses_post( $args['image'] ); ?>
				</a>
			<?php endif; ?>
		</div>
		<div class="card-content">
			<div class="card-top">
				<div class="card-title-wrapper">
					<a href="<?php echo esc_url( $args['url'] ); ?>">
						<p class="client"><?php echo esc_html( rm_display_client()->name ); ?></p>
						<h3 class="card-title"><?php echo esc_html( $args['title'] ); ?></h3>
					</a>
				</div>
			</div>
			<div class="card-footer">
				<ul class="tag-list">
					<?php foreach ( $tags as $t ) : ?>
					<li class="tag">
						<a href="<?php echo esc_url( get_term_link( $t ) ); ?>"><?php echo esc_html( $t->name ); ?></a>
					</li>
					<?php endforeach; ?>
				</ul>
			</div>
		</div>
	</div>
		<?php
}

/**
 * Display a blog card.
 *
 * @author Kelsey
 * @param array $args Card defaults.
 * @since 1.0
 */
function rm_display_blog_card( $args = array() ) {

	global $post;

	// Setup defaults.
	$defaults = array(
		'title' => '',
		'image' => '',
		'text'  => '',
		'url'   => '',
		'date'  => '',
	);

	// Parse args.
	$args = wp_parse_args( $args, $defaults );

	$categories_list = get_the_category( $post->ID );

	?>

	<div class="blog-card card">
		<div class="card-img">
			<?php if ( $args['image'] ) : ?>
				<a href="<?php echo esc_url( $args['url'] ); ?>" tabindex="-1" class="img-wrapper" style="background-color: <?php echo esc_attr( $client_color ); ?>;">
					<?php echo wp_kses_post( $args['image'] ); ?>
				</a>
			<?php endif; ?>
		</div>
		<div class="card-content">
			<div class="card-title-wrapper">
				<a href="<?php echo esc_url( $args['url'] ); ?>">
					<h3 class="card-title"><?php echo esc_html( $args['title'] ); ?></h3>
					<p class="date"><?php echo esc_html( $args['date'] ); ?></p>
				</a>
			</div>
			<div class="blog-tags">
				<ul>
					<?php
					foreach ( $categories_list as $cat ) :
						?>
							<li><a href="<?php echo esc_url( get_category_link( $cat ) ); ?>"><?php echo esc_html( $cat->name ); ?></a></li>
						<?php
					endforeach;
					?>
				</ul>
			</div>
		</div>
	</div>
		<?php
}

/**
 * Display a team card.
 *
 * @author Kelsey
 * @param array $args Card defaults.
 * @since 1.0
 */
function rm_display_team_card( $args = array() ) {

	global $post;

	// Setup defaults.
	$defaults = array(
		'title' => '',
		'image' => '',
		'text'  => '',
		'url'   => '',
	);

	// Parse args.
	$args = wp_parse_args( $args, $defaults );

	$this_title = get_field( 'title', $post->ID );

	?>

	<div class="team-card card">
		<div class="card-img">
			<?php if ( $args['image'] ) : ?>
				<a href="<?php echo esc_url( $args['url'] ); ?>" tabindex="-1" class="img-wrapper" style="background-color: <?php echo esc_attr( $client_color ); ?>;">
					<?php echo wp_kses_post( $args['image'] ); ?>
				</a>
			<?php endif; ?>
		</div>
		<div class="card-content">
			<div class="card-title-wrapper">
				<a href="<?php echo esc_url( $args['url'] ); ?>">
					<h3 class="card-title"><?php echo esc_html( $args['title'] ); ?></h3>
					<p class="title"><?php echo esc_html( $this_title ); ?></p>
				</a>
			</div>
		</div>
	</div>
		<?php
}

/**
 * Display a news post card.
 *
 * @author Kelsey
 * @param array $args Card defaults.
 * @since 1.0
 */
function rm_display_article_card( $args = array() ) {

	global $post;

	// Setup defaults.
	$defaults = array(
		'title' => '',
		'image' => '',
		'text'  => '',
		'url'   => '',
	);

	// Parse args.
	$args = wp_parse_args( $args, $defaults );

	$this_title = get_field( 'title', $post->ID );

	?>

	<div class="post-card card flex flex-wrap w-full mb-32">
		<div class="card-img tablet-landscape:w-6/12">
			<?php if ( $args['image'] ) : ?>
				<a href="<?php echo esc_url( $args['url'] ); ?>" tabindex="-1" class="img-wrapper" style="background-color: <?php echo esc_attr( $client_color ); ?>;">
					<?php echo wp_kses_post( $args['image'] ); ?>
				</a>
			<?php endif; ?>
		</div>
		<div class="card-content tablet-portrait:w-6/12 tablet-portrait:pl-32">
			<div class="card-title-wrapper">
				<a href="<?php echo esc_url( $args['url'] ); ?>">
					<h3 class="card-title"><?php echo esc_html( $args['title'] ); ?></h3>
					<p class="title"><?php echo esc_html( $this_title ); ?></p>
				</a>
			</div>
			<div class="content">
				<?php the_excerpt(); ?>
				<a href="<?php echo esc_url( $args['url'] ); ?>" class="button">Read More</a>
			</div>
		</div>
	</div>
		<?php
}

/**
 * Display the tagged client.
 *
 * @author Kelsey
 * @since 1.0
 */
function rm_display_client() {

	global $post;

	$client = wp_get_post_terms( $post->ID, 'client' );

	return $client[0];

}

/**
 * Display further client work.
 *
 * @author Kelsey
 * @since 1.0
 */
function rm_related_projects() {

	global $post;

	$query = new WP_Query(
		array(
			'post_type'    => 'portfolio',
			'post__not_in' => array( $post->ID ),
			'tax_query'    => array(
				array(
					'taxonomy' => 'client',
					'field'    => 'slug',
					'terms'    => rm_display_client()->slug,
				),

			),
		)
	);
	if ( $query->have_posts() ) :
		?>

	<div class="container">
		<div class="further-work">
		<h2>Further work for <?php echo esc_html( rm_display_client()->name ); ?></h2>
			<div class="project-grid grid col-3">
				<?php
				while ( $query->have_posts() ) :
					$query->the_post();

					global $post;

					rm_display_project_card(
						array(
							'title' => get_field( 'card_title', get_the_ID() ),
							'image' => wp_get_attachment_image( get_post_thumbnail_id(), 'project-thumb' ),
							'url'   => get_the_permalink(),
						)
					);
				endwhile;
				wp_reset_postdata();
				?>
			</div>
		</div>
	</div>
		<?php
endif;

}

/**
 * Get portfolio query.
 *
 * @param array $args query rules.
 * @return object The related posts object.
 * @author RM
 */
function rm_portfolio_posts( $args = array() ) {

	// Setup default WP_Query args.
	$defaults = array(
		'orderby'        => 'date',
		'order'          => 'ASC',
		'posts_per_page' => 12,
		'post_type'      => 'portfolio',
	);

	$args = array_merge( $defaults, $args );

	// Run the query!
	$portfolio = new WP_Query( $args );

	return $portfolio;
}

/**
 * Get blog query.
 *
 * @param array $args query rules.
 * @return object The related posts object.
 * @author RM
 */
function rm_get_posts( $args = array() ) {

	// Setup default WP_Query args.
	$defaults = array(
		'orderby'        => 'date',
		'order'          => 'ASC',
		'posts_per_page' => 12,
	);

	$args = array_merge( $defaults, $args );

	// Run the query!
	$portfolio = new WP_Query( $args );

	return $portfolio;
}


/**
 * The portfolio loop.
 *
 * @author Kelsey
 * @param array $args Card defaults.
 * @since 1.0
 */
function rm_portfolio_loop( $args = array() ) {

	$query = rm_portfolio_posts( $args );

	ob_start();

	if ( $query->have_posts() ) :
		while ( $query->have_posts() ) :
			$query->the_post();
			rm_display_project_card(
				array(
					'title' => get_field( 'card_title', get_the_ID() ),
					'image' => wp_get_attachment_image( get_post_thumbnail_id(), 'project-thumb' ),
					'url'   => get_the_permalink(),
				)
			);
		endwhile;
		wp_reset_postdata();
	endif;
	return ob_get_clean();

}

/**
 * The blog loop.
 *
 * @author Kelsey
 * @param array $args Card defaults.
 * @since 1.0
 */
function rm_blog_loop( $args = array() ) {

	$query = rm_get_posts( $args );

	ob_start();

	if ( $query->have_posts() ) :
		while ( $query->have_posts() ) :
			$query->the_post();
			rm_display_blog_card(
				array(
					'title' => get_the_title(),
					'image' => wp_get_attachment_image( get_post_thumbnail_id(), 'project-thumb' ),
					'url'   => get_the_permalink(),
					'date'  => get_the_date(),
				)
			);

		endwhile;
		wp_reset_postdata();
	endif;
	return ob_get_clean();

}

/**
 * The team loop.
 *
 * @author Kelsey
 * @param array $args Card defaults.
 * @since 1.0
 */
function rm_team_loop( $args = array() ) {

	$query = rm_get_posts( $args );

	ob_start();

	if ( $query->have_posts() ) :
		while ( $query->have_posts() ) :
			$query->the_post();
			rm_display_team_card(
				array(
					'title' => get_the_title(),
					'image' => wp_get_attachment_image( get_post_thumbnail_id(), 'full' ),
					'url'   => get_the_permalink(),
				)
			);

		endwhile;
		wp_reset_postdata();
	endif;
	return ob_get_clean();

}


/**
 * Find number of posts.
 *
 * @author Kelsey
 * @param string $post_type post type.
 * @since 1.0
 */
function rm_number_of_posts( $post_type = '' ) {

	$post_numb = wp_count_posts( $post_type );
	return $post_numb->publish;

}

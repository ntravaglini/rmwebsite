<?php
/**
 * The template for displaying pages.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package Raborn Media
 */

get_header(); ?>

	<main id="main" class="page-main">

		<?php
			get_template_part( 'template-parts/partials/page-header' );
		?>

		<?php
			get_template_part( 'template-parts/content-page' );
		?>

	</main><!-- #main -->

<?php get_footer(); ?>

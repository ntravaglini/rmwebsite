<?php
/**
 * The template for displaying all single posts.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package Raborn Media
 */

$this_post_type = get_post_type();

get_header(); ?>

	<main id="main" class="main-page site-main">

		<?php
		if ( 'portfolio' === $this_post_type ) {
			get_template_part( 'template-parts/partials/portfolio-header' );
		} elseif ( 'team' === $this_post_type ) {
			get_template_part( 'template-parts/partials/team-header' );
		} elseif ( 'post' === $this_post_type ) {
			get_template_part( 'template-parts/partials/article-header' );
		} else {
			get_template_part( 'template-parts/partials/page-header' );
		}
		?>

		<?php
		while ( have_posts() ) :
			the_post();

			get_template_part( 'template-parts/content', get_post_type() );

			rm_display_comments();

		endwhile; // End of the loop.
		?>

	</main><!-- #main -->
	<?php if ( 'skills' === $this_post_type || 'services' === $this_post_type || 'industries' === $this_post_type ) : ?>
		<div class="cta container">
			<?php dynamic_sidebar( 'services' ); ?>
		</div>
	<?php endif; ?>

<?php get_footer(); ?>

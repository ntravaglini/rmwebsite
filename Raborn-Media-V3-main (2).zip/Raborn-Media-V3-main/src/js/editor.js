/**
 * Register block styles.
 */

/**
 * WordPress dependencies.
 */
import { registerBlockStyle } from '@wordpress/blocks';
import { __ } from '@wordpress/i18n';

/**
 * Button Media styles.
 *
 * @type {Array}
 */
const layoutStyleButton = [
	{
		name: 'rm-skew-button',
		label: __( 'Skewed Button', 'rm' ),
	},
];

/**
 * Register styles.
 *
 * @return {void}
 */
const register = () => {
	// eslint-disable-next-line no-console
	console.log( 'test' );

	layoutStyleButton.forEach( ( layoutStyle ) =>
		registerBlockStyle( 'core/button', layoutStyle )
	);
};

/**
 * Register and unregister styles on dom ready.
 */
wp.domReady( () => {
	register();
} );

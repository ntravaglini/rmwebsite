/* eslint-disable no-undef */
/**
 * File: filter.js
 *
 * Manage our portfolio filter.
 */

// Make sure everything is loaded first.
if (
	( 'complete' === document.readyState ||
		'loading' !== document.readyState ) &&
	! document.documentElement.doScroll
) {
	rmFilterParent();
	rmSubFilter();
	portfolioAjax( jQuery );
} else {
	document.addEventListener( 'DOMContentLoaded', rmFilterParent );
	document.addEventListener( 'DOMContentLoaded', rmSubFilter );
	document.addEventListener( 'DOMContentLoaded', portfolioAjax( jQuery ) );
}

/**
 * Filter function
 *
 * @author Kelsey
 */
function rmFilterParent() {
	const filters = document.querySelectorAll( '.filter-list-main' );

	filters.forEach( ( filter ) => {
		const filterItems = filter.querySelectorAll( '.menu-item' );

		filterItems.forEach( ( item ) => {
			item.addEventListener( 'click', filterActive );
		} );
	} );

	function filterActive( e ) {
		e.preventDefault();
		const activeItem = e.target;

		const subFilter = document.querySelector(
			`[data-tax="${ activeItem.dataset.type }"]`
		);

		gsap.set( subFilter, {
			y: 40,
			opacity: 0,
		} );

		subFilter.classList.add( 'showing' );
		gsap.to( subFilter, {
			y: 0,
			opacity: 1,
		} );

		if ( ! activeItem.classList.contains( 'active' ) ) {
			removeActive( e );
			activeItem.classList.add( 'active' );
			activeItem
				.closest( '.menu-item' )
				.classList.add( 'current-menu-item' );
		}
	}

	function removeActive( e ) {
		const activeFilter = e.target.closest( '.filter-list-main' );
		const active = activeFilter.querySelector( '.active' );
		active.classList.remove( 'active' );
		active.closest( '.menu-item' ).classList.remove( 'current-menu-item' );

		const subFilter = document.querySelector(
			`[data-tax="${ active.dataset.type }"]`
		);

		subFilter.classList.remove( 'showing' );
	}
}

/**
 * Filter function
 *
 * @author Kelsey
 */
function rmSubFilter() {
	const filters = document.querySelectorAll( '.filter-list' );

	filters.forEach( ( filter ) => {
		const filterItems = filter.querySelectorAll( '.filter-item' );

		filterItems.forEach( ( item ) => {
			item.addEventListener( 'click', filterActive );
		} );
	} );

	function filterActive( e ) {
		e.preventDefault();
		const activeItem = e.target;

		if ( ! activeItem.classList.contains( 'active' ) ) {
			removeActive( e );
			activeItem.classList.add( 'active' );
		}
	}

	function removeActive( e ) {
		const activeFilter = e.target.closest( '.filter-list' );
		const active = activeFilter.querySelector( '.active' );
		active.classList.remove( 'active' );
	}
}

/**
 * AJAX Filter Functionality
 *
 * @param {Object} $ jQuery.
 * @author Kelsey
 */
function portfolioAjax( $ ) {
	const $filter = '.filter-item a';
	const $loadMore = '.show-more-results';
	let $offset = 12;

	// On selction of one of the main filters.

	jQuery( document ).on( 'click', $filter, function ( e ) {
		e.preventDefault();

		// catalog type.
		const type = $( '.page-navigation .current-menu-item a' ).data(
			'type'
		);
		const tax = $( this ).data( 'slug' );

		runAjax( tax, type );
	} );

	function runAjax( tax, type ) {
		$offset = 12;
		$.ajax( {
			url: wp_ajax.ajax_url,
			data: {
				action: 'port_filter',
				tax,
				type,
			},
			cache: false,
			type: 'post',
			beforeSend() {},
			success( result ) {
				$( $loadMore ).show();
				gsap.set( '.portfolio-grid', {
					y: 100,
				} );
				$( '.portfolio-grid' ).html( result.query );
				gsap.to( '.portfolio-grid', {
					y: 0,
					opacity: 1,
				} );

				if ( $offset < result.post_found ) {
					$( $loadMore ).show();
				} else {
					$( $loadMore ).hide();
				}
			},
			// error( result ) {
			// 	console.warn( result );
			// },
		} );
	}

	$( document ).on( 'click', $loadMore, function ( e ) {
		e.preventDefault();

		// catalog type.
		const type = $( '.page-navigation .current-menu-item a' ).data(
			'type'
		);

		const tax = $( `[data-tax="${ type }"] .filter-item .active` ).data(
			'slug'
		);

		$.ajax( {
			url: wp_ajax.ajax_url,
			data: {
				action: 'port_filter',
				tax,
				type,
				offset: $offset,
			},
			cache: false,
			type: 'post',
			beforeSend() {},
			success( result ) {
				$( '.portfolio-grid' ).append( result.query ).fadeIn( 500 );
				$offset += 12;

				if ( $offset <= result.post_found ) {
					$( $loadMore ).show();

					if ( $offset === result.post_found ) {
						$( $loadMore ).hide();
					}
				} else {
					$( $loadMore ).hide();
				}

				if ( $offset >= $postNumb ) {
					$( $loadMore ).hide();
				}
			},
			// error( result ) {
			// 	console.warn( result );
			// },
		} );
	} );
}

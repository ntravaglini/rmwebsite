<?php
/**
 * The template used for displaying related work.
 *
 * @package Raborn Media
 */

// Set up fields.

global $post;

$alignment = rm_get_block_alignment( $block );
$classes   = rm_get_block_classes( $block );
$post_num  = get_field( 'post_number' );

$args = array(
	'posts_per_page' => $post_num,
	'orderby'        => 'date',
);

?>

<div id="<?php echo esc_attr( $block['id'] ); ?>" class="blog-grid-block <?php echo esc_attr( $alignment ); ?> <?php echo esc_attr( $classes ); ?>">
	<div class="grid col-3">
		<?php
		echo wp_kses_post( rm_blog_loop( $args ) );
		?>
	</div>
</div>

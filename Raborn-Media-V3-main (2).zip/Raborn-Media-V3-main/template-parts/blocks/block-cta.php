<?php
/**
 * The template used for displaying the CTA block.
 *
 * @package Raborn Media
 */

// Set up fields.

$alignment   = rm_get_block_alignment( $block );
$classes     = rm_get_block_classes( $block );
$headline    = get_field( 'main_headline' );
$sub_headine = get_field( 'sub_headline' );
$links       = 'links';
$mobile_link = get_field( 'mobile_link' );
$img         = get_field( 'image' );
?>

<section id="<?php echo esc_attr( $block['id'] ); ?>"  class="page-cta <?php echo esc_attr( $alignment ); ?> <?php echo esc_attr( $classes ); ?>">
	<?php echo do_shortcode( rm_get_custom_svg( 'cta-top' ) ); ?>
	<div class="inner-top">
		<div class="angled-bg angled-bg--top-to-bottom">
		</div>
		<div class="cta-container">
			<div class="cta-left">
					<h2><?php echo esc_html( $headline ); ?></h2>
					<p class="subheadline"><?php echo esc_html( $sub_headine ); ?></p>
					<a href="<?php echo esc_url( $mobile_link['url'] ); ?>" class="button bg-blue mobile-btn"><?php echo esc_html( $mobile_link['title'] ); ?></a>
					<?php
					if ( have_rows( $links ) ) :
						?>
						<div class="service-links grid">
							<?php
							// Loop through rows.
							while ( have_rows( $links ) ) :
								the_row();

								// Load sub field value.
								$this_link = get_sub_field( 'link' );
								?>
								<div class="link-wrapper"><a href="<?php echo esc_url( $this_link['url'] ); ?>"><?php echo esc_html( $this_link['title'] ); ?></a></div>
								<?php
								// End loop.
							endwhile;
							?>
						</div>
						<?php
					endif;
					?>
				</div>
				<div class="cta-right">
					<?php echo wp_get_attachment_image( $img, 'full' ); ?>
				</div>
			</div>
		</div>
	<div class="inner-bottom">
		<div class="angled-bg angled-bg--bottom-to-top">
		</div>
	</div>
	<?php echo do_shortcode( rm_get_custom_svg( 'cta-bottom' ) ); ?>
	<?php echo do_shortcode( rm_get_custom_svg( 'circle-pattern' ) ); ?>
</section>

<?php
/**
 * The template used for displaying the meet team block.
 *
 * @package Raborn Media
 */

// Set up fields.

global $post;

$alignment    = rm_get_block_alignment( $block );
$classes      = rm_get_block_classes( $block );
$logo         = get_field( 'logo' );
$headline     = get_field( 'headline' );
$sub_headline = get_field( 'sub_headline' );
$this_link    = get_field( 'link' );
$bg_img       = get_field( 'bg_image' );

?>

<div id="<?php echo esc_attr( $block['id'] ); ?>" class="meet-team-block <?php echo esc_attr( $alignment ); ?> <?php echo esc_attr( $classes ); ?>" style="background-image:url(<?php echo esc_url( $bg_img ); ?>);">
	<div class="bg-overlay">
	</div>
	<div class="md-section">
        <?php echo wp_get_attachment_image( $logo, 'full' ); ?>
        <h2><?php echo esc_html( $headline ); ?></h2>
        <p class="sub-headline">
            <?php echo esc_html( $sub_headline ); ?>
        </p>
        <div class="btn-wrapper">
            <div class="is-style-rm-skew-button">
                <a href="<?php echo esc_url( $this_link['url'] ); ?>" class="btn"><?php echo esc_html( $this_link['title'] ); ?></a>
            </div>
        </div>
        
    </div>
</div>

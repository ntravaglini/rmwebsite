<?php
/**
 * The template used for displaying the recent courses grid block.
 *
 * @package Raborn Media
 */

// Set up fields.

$alignment = rm_get_block_alignment( $block );
$classes   = rm_get_block_classes( $block );
$this_menu = strtolower( get_field( 'menu_slug' ) );

?>

<section id="<?php echo esc_attr( $block['id'] ); ?>" class="pg-nav<?php echo esc_attr( $alignment ); ?> <?php echo esc_attr( $classes ); ?>">
	<nav class="page-navigation" aria-label="<?php esc_attr_e( 'Page Navigation', 'rm' ); ?>">
		<?php
		wp_nav_menu(
			[
				'fallback_cb' => false,
				'menu'        => str_replace( ' ', '-', $this_menu ),
				'menu_class'  => 'menu',
				'container'   => false,
			]
		);
		?>
	</nav><!-- #site-navigation-->
</section>

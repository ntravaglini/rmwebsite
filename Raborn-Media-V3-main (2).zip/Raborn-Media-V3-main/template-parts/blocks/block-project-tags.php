<?php
/**
 * The template used for displaying related services.
 *
 * @package Raborn Media
 */

// Set up fields.

global $post;

$alignment  = rm_get_block_alignment( $block );
$classes    = rm_get_block_classes( $block );
$this_title = get_field( 'block_title' );

$tags = wp_get_post_terms( $post->ID, array( 'skills', 'industries', 'services' ) );

?>

<div id="<?php echo esc_attr( $block['id'] ); ?>" class="project-tags-block">
	<h3 class="block-title"><?php echo esc_html( $this_title ); ?></h3>
	<ul class="tag-list">
		<?php foreach ( $tags as $t ) : ?>
		<li class="tag">
			<a href="<?php echo esc_url( get_term_link( $t ) ); ?>"><?php echo esc_html( $t->name ); ?></a>
		</li>
		<?php endforeach; ?>
	</ul>
</div>

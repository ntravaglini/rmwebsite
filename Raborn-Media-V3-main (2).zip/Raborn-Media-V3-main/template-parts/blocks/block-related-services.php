<?php
/**
 * The template used for displaying related services.
 *
 * @package Raborn Media
 */

// Set up fields.

$alignment      = rm_get_block_alignment( $block );
$classes        = rm_get_block_classes( $block );
$service        = get_post_type();
$services_query = rm_get_services_query( $service );
$this_title     = get_field( 'block_title' );

global $post;

if ( 0 === $post->post_parent ) {
	$this_id = get_the_ID();
} else {
	$this_id = $post->post_parent;
}

$sub_pages_args = array(
	'post_type'    => $service,
	'post_parent'  => $this_id,
	'post__not_in' => array( get_the_ID() ),
);

$sub_pages = rm_get_services_subpages( $sub_pages_args );

?>

<div id="<?php echo esc_attr( $block['id'] ); ?>" class="related-services-block">
	<h3 class="block-title"><?php echo esc_html( $this_title ); ?></h3>
	<?php
		rm_tag_list( $sub_pages );
	?>
</div>

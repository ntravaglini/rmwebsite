<?php
/**
 * The template used for displaying related work.
 *
 * @package Raborn Media
 */

// Set up fields.

global $post;

$alignment      = rm_get_block_alignment( $block );
$classes        = rm_get_block_classes( $block );
$this_title     = get_field( 'block_title' );
$service        = get_post_type();
$services_query = rm_get_services_query( $service );

$args = array(
	'posts_per_page' => 12,
	'tax_query'      => array(
		array(
			'taxonomy'         => $service,
			'field'            => 'slug',
			'terms'            => $post->post_name,
			'include_children' => false,

		),
	),
);

?>

<div id="<?php echo esc_attr( $block['id'] ); ?>" class="related-work-block <?php echo esc_attr( $alignment ); ?> <?php echo esc_attr( $classes ); ?>">
	<span class="flex justify-center">
		<a href="/work" class="wp-block-button__link has-white-color has-blue-dark-background-color has-text-color has-background">Back to Work</a>
	</span>
	<h3 class="text-center text-heading-xs text-blue-dark my-32"><?php echo esc_html( $this_title ); ?></h3>
	<div class="portfolio-grid grid col-3">
		<?php
		echo wp_kses_post( rm_portfolio_loop( $args ) );
		?>
	</div>
</div>

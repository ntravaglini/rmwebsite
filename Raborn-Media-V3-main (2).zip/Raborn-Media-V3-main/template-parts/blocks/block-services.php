<?php
/**
 * The template used for displaying services.
 *
 * @package Raborn Media
 */

// Set up fields.

$alignment = rm_get_block_alignment( $block );
$classes   = rm_get_block_classes( $block );
$service   = get_field( 'service_type' );
$format    = get_field( 'display_format' );

$services_query = rm_get_services_query( $service );

?>

<section id="<?php echo esc_attr( $block['id'] ); ?>" class="services-block <?php echo esc_attr( $alignment ); ?> <?php echo esc_attr( $classes ); ?> <?php echo esc_attr( $format ); ?>">
	<?php
	if ( $services_query->have_posts() ) :
		while ( $services_query->have_posts() ) :
			$services_query->the_post();
			rm_display_services_card(
				array(
					'title'   => get_the_title(),
					'image'   => wp_get_attachment_image( get_post_thumbnail_id(), 'card-image' ),
					'url'     => get_the_permalink(),
					'excerpt' => get_the_excerpt(),
					'ID'      => get_the_ID(),
					'type'    => $service,
				)
			);

		endwhile;
		wp_reset_postdata();
	endif;
	?>
</section>

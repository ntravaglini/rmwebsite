<?php
/**
 * The template used for displaying the team grid.
 *
 * @package Raborn Media
 */

// Set up fields.

global $post;

$alignment   = rm_get_block_alignment( $block );
$classes     = rm_get_block_classes( $block );
$block_title = get_field( 'block_title' );

$args = array(
	'posts_per_page' => -1,
	'orderby'        => 'menu_order',
	'post_type'      => 'team',
);

?>

<div id="<?php echo esc_attr( $block['id'] ); ?>" class="team-grid-block <?php echo esc_attr( $alignment ); ?> <?php echo esc_attr( $classes ); ?>">
	<h2 class="block-title text-center mb-32"><?php echo esc_html( $block_title ); ?></h2>
	<div class="grid col-4">
		<?php
		echo wp_kses_post( rm_team_loop( $args ) );
		?>
	</div>
</div>

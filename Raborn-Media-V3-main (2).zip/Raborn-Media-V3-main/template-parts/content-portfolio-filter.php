<?php
/**
 * Template part for displaying the portfolio filter.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Raborn Media
 */

$total_num = rm_number_of_posts( 'portfolio' );


$skill_filters = get_terms(
	array(
		'parent'     => 0,
		'taxonomy'   => 'skills',
		'hide_empty' => false,
	)
);

$service_filters = get_terms(
	array(
		'parent'     => 0,
		'taxonomy'   => 'services',
		'hide_empty' => false,
	)
);

$industry_filters = get_terms(
	array(
		'parent'     => 0,
		'taxonomy'   => 'industries',
		'hide_empty' => false,
	)
);

$args = array(
	'posts_per_page' => 12,
	'post_parent'    => 0,
);

?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<div class="entry-content container">
	<button class="modal-trigger filter-btn" data-target="#portfolio-filter">Filter Work</button>
		<div class="modal" id="portfolio-filter" tabindex="-1">
			<div class="modal-content portfolio-filter">
				<button class="close" data-target="#portfolio-filter">
					<i class="close-icon" aria-hidden="true"></i></button>
				<div class="filter-list-main page-navigation">
					<ul class="menu">
						<span class="message">Filter By:</span>
						<li class="menu-item current-menu-item"><a class="active" href="#" data-type="skills">Skill</a> </li>
						<li class="menu-item"><a href="#" data-type="services">Service</a> </li>
						<li class="menu-item"><a href="#" data-type="industries">Industry</a> </li>
					</ul>
				</div>
				<div class="filter-list-skills filter-list showing" data-tax="skills">
					<ul class="filter-group">
						<li class="placeholder"><a href="#" data-filter="all">All</a> </li>
						<li class="filter-item"><a class="active" href="#" data-filter="all" data-slug="all">All</a> </li>
						<?php foreach ( $skill_filters as $filter ) { ?>
							<li class="filter-item"><a href="#" data-filter="<?php echo esc_html( $filter->name ); ?>" data-slug="<?php echo esc_html( $filter->slug ); ?>"><?php echo esc_html( $filter->name ); ?></a> </li>
						<?php } ?>
					</ul>
				</div>
				<div class="filter-list-services filter-list" data-tax="services">
					<ul class="filter-group">
						<li class="placeholder"><a href="#" data-filter="all">All</a> </li>
						<li class="filter-item"><a class="active" href="#" data-filter="all" data-slug="all">All</a> </li>
						<?php foreach ( $service_filters as $filter ) { ?>
							<li class="filter-item"><a href="#" data-filter="<?php echo esc_html( $filter->name ); ?>" data-slug="<?php echo esc_html( $filter->slug ); ?>"><?php echo esc_html( $filter->name ); ?></a> </li>
						<?php } ?>
					</ul>
				</div>
				<div class="filter-list-industries filter-list" data-tax="industries">
					<ul class="filter-group">
						<li class="placeholder"><a href="#" data-filter="all">All</a> </li>
						<li class="filter-item"><a class="active" href="#" data-filter="all" data-slug="all">All</a> </li>
						<?php foreach ( $industry_filters as $filter ) { ?>
							<li class="filter-item"><a href="#" data-filter="<?php echo esc_html( $filter->name ); ?>" data-slug="<?php echo esc_html( $filter->slug ); ?>"><?php echo esc_html( $filter->name ); ?></a> </li>
						<?php } ?>
					</ul>
				</div>
			</div>
		</div>
		<div class="portfolio-grid grid col-3">
			<?php echo wp_kses_post( rm_portfolio_loop( $args ) ); ?>
		</div>
		<?php if ( $total_num > 12 ) { ?>
			<div class="show-more-results-wrapper">
				<button class="button show-more-results"><span>Load More</span></button>
			</div>
		<?php } ?>
		<?php
			the_content();

			wp_link_pages(
				[
					'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'rm' ),
					'after'  => '</div>',
				]
			);
			?>
	</div><!-- .entry-content -->
</article><!-- #post-## -->


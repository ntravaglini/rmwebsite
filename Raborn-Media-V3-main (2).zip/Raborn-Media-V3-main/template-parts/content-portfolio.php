<?php
/**
 * Template part for displaying portfolio items.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Raborn Media
 */

?>

	<article <?php post_class( 'post-container container' ); ?>>

		<div class="entry-content">
			<?php
				the_content(
					sprintf(
						wp_kses(
							/* translators: %s: Name of current post. */
							esc_html__( 'Continue reading %s <span class="meta-nav">&rarr;</span>', 'rm' ),
							[
								'span' => [
									'class' => [],
								],
							]
						),
						the_title( '<span class="screen-reader-text">"', '"</span>', false )
					)
				);
				?>
		</div><!-- .entry-content -->

	</article><!-- #post-## -->
<?php
get_template_part( 'template-parts/partials/project-bottom' );


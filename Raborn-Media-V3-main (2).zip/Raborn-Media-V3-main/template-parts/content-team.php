<?php
/**
 * Template part for displaying team member content in single.php.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Raborn Media
 */

$this_title = get_field( 'title' );
$email      = get_field( 'email' );
$phone      = get_field( 'phone' );

?>

	<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
		<div class="entry-content container team-member mt-56">
			<div class="team-img">
				<?php echo get_the_post_thumbnail( $post_id, 'full' ); ?>
			</div>
			<div class="bio">
				<div class="info">
					<h2><?php echo esc_html( get_the_title() ); ?></h2>
					<p class="title"><?php echo esc_html( $this_title ); ?></p>
				</div>
				<div class="contact">
					<p class="email"><a href="mailto:<?php echo esc_attr( $email ); ?>"><?php echo esc_html( $email ); ?></a></p>
					<p class="phone"><a href="tel:<?php echo esc_attr( $phone ); ?>"><?php echo esc_html( $phone ); ?></a></p>
				</div>
			<?php
				the_content();

				wp_link_pages(
					[
						'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'rm' ),
						'after'  => '</div>',
					]
				);
				?>
			</div>
		</div><!-- .entry-content -->

		<?php if ( get_edit_post_link() ) : ?>
			<footer class="entry-footer">
				<?php
					edit_post_link(
						sprintf(
							/* translators: %s: Name of current post */
							esc_html__( 'Edit %s', 'rm' ),
							the_title( '<span class="screen-reader-text">"', '"</span>', false )
						),
						'<span class="edit-link">',
						'</span>'
					);
				?>
			</footer><!-- .entry-footer -->
		<?php endif; ?>

	</article><!-- #post-## -->
<?php
get_template_part( 'template-parts/partials/project-bottom' );

<div class="font-sans-bold"></div>
<div class="font-sans-light"></div>
<div class="font-sans-semibold"></div>
<div class="font-sans-medium"></div>
<div class="text-blue"></div>
<div class="text-blue-dark"></div>
<div class="text-pink"></div>

<?php
/**
 * Template part for displaying the article header.
 *
 * @package Raborn Media
 */

?>

<div class="hero-image">
	<?php echo get_the_post_thumbnail( $post_id, 'project-hero' ); ?>
</div>
<header class="portfolio-header container">

	<?php the_title( '<h1 class="entry-title text-center text-blue-dark">', '</h1>' ); ?>

</header><!-- .entry-header -->

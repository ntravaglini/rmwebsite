<?php
/**
 * Template part for displaying the home brands.
 *
 * @package Raborn Media
 */

$brands  = get_field( 'brands' );
$gallery = $brands['logos'];
?>

<section class="home-brands">
	<div class="inner-top">
		<div class="angled-bg bg-blue-gradient angled-bg--top-to-bottom">
		</div>
		<div class="brands-inner container">
			<h2><?php echo esc_html( $brands['headline'] ); ?></h2>
			<div class="brand-gallery-wrapper">
				<ul class="brand-gallery">
					<?php foreach ( $gallery as $image_id ) : ?>
						<li>
							<?php echo wp_get_attachment_image( $image_id, 'full' ); ?>
						</li>
					<?php endforeach; ?>
				</ul>
			</div>
		</div>
	</div>
</section>

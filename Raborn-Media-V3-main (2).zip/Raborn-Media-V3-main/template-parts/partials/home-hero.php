<?php
/**
 * Template part for displaying the home hero.
 *
 * @package Raborn Media
 */

$this_post_type = get_post_type();

$home_headline = get_field( 'headline' );
$hero_links    = get_field( 'hero_links' );
?>

<header class="home-header">
	<div class="inner-header container">
		<div class="header-left">
			<h1 class="page-title">
				<span><?php echo wp_kses_post( $home_headline['sub_headline'] ); ?></span>
				<?php echo wp_kses_post( $home_headline['large_headline'] ); ?>
			</h1>
			<h2><?php echo esc_html( $hero_links['headline'] ); ?></h2>


			<?php
			if ( have_rows( 'hero_links' ) ) :
				while ( have_rows( 'hero_links' ) ) :
					the_row();
					// Check rows exists.
					if ( have_rows( 'links' ) ) :
						?>
						<div class="service-links grid">
							<?php
							// Loop through rows.
							while ( have_rows( 'links' ) ) :
								the_row();

								// Load sub field value.
								$this_link    = get_sub_field( 'link' );
								$this_link_id = get_sub_field( 'link_id' );
								$row_count    = get_row_index();
								?>
								<div class="link-wrapper<?php echo ( 1 === $row_count ) ? ' active' : ''; ?>"><a href="<?php echo esc_url( $this_link['url'] ); ?>" id="<?php echo esc_attr( $this_link_id ); ?>"><?php echo esc_html( $this_link['title'] ); ?></a></div>
								<?php
								// End loop.
							endwhile;
							?>
						</div>
							<?php
						endif;
				endwhile;
			endif;
			?>
		</div>
		<div class="header-right">
			<?php
			if ( have_rows( 'hero_slider' ) ) :
				?>
				<div class="home-slider">
					<?php echo do_shortcode( rm_get_custom_svg( 'rm-circle' ) ); ?>
					<?php
					// Loop through rows.
					while ( have_rows( 'hero_slider' ) ) :
						the_row();

						// Load sub field value.
						$slide      = get_sub_field( 'slide_graphic' );
						$slide_id   = get_sub_field( 'data_attribute' );
						$slide_hl   = get_sub_field( 'headline' );
						$slide_link = get_sub_field( 'link' );
						$max_width  = 'max-width: ' . get_sub_field( 'max-width' ) . 'px';
						?>
						<div class="slide" slide-data="<?php echo esc_attr( $slide_id ); ?>" >
							<div class="slide-text">
								<h2><?php echo esc_html( $slide_hl ); ?></h2>
								<a href="<?php echo esc_url( $slide_link['url'] ); ?>" class="arrow-btn"><?php echo esc_html( $slide_link['title'] ); ?></a>
							</div>
							<?php
								echo wp_get_attachment_image( $slide, 'full', '', array( 'style' => $max_width ) );
							?>
						</div>
						<?php
						// End loop.
					endwhile;
					?>
				</div>
					<?php
				endif;
			?>
		</div>
	</div>
	<?php echo do_shortcode( rm_get_custom_svg( 'home-dots' ) ); ?>
</header><!-- .entry-header -->

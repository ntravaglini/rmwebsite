<?php
/**
 * Template part for displaying the home testimonials.
 *
 * @package Raborn Media
 */

$testimonials = 'testimonails_2';

?>

<section class="home-testimonials">
<?php echo do_shortcode( rm_get_custom_svg( 'testimonial-highlight-top' ) ); ?>
	<div class="testimonials-inner">
	<?php
		// Check rows exists.
	if ( have_rows( $testimonials ) ) :

		// Loop through rows.
		while ( have_rows( $testimonials ) ) :
			the_row();

			// Load sub field value.
			$name       = get_sub_field( 'name' );
			$this_title = get_sub_field( 'title' );
			$organization = get_sub_field( 'organization' );
			$message    = get_sub_field( 'message' );
			$img        = get_sub_field( 'headshot' );
			$i          = get_row_index();
			?>
			<div class="testimonial block-<?php echo esc_attr( $i ); ?>">
				<div class="inner">
					<?php
					echo wp_get_attachment_image( $img, 'full' );
					?>
					<p>
						<?php echo esc_html( $message ); ?>
					</p>
					<h3><?php echo esc_html( $name ); ?></h3>
					<p class="title"><?php echo esc_html( $this_title ); ?>
					<br><?php echo esc_html( $organization ); ?></p>
				</div>
			</div>

			<?php
			// End loop.
		endwhile;
	endif;
	?>
	</div>
	<?php echo do_shortcode( rm_get_custom_svg( 'testimonial-highlight-bottom' ) ); ?>
</section>

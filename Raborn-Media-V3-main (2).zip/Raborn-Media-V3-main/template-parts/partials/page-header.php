<?php
/**
 * Template part for displaying the page header.
 *
 * @package Raborn Media
 */

$this_post_type = get_post_type();
?>

<header class="entry-header">
	<div class="inner-header">
		<?php echo do_shortcode( rm_get_custom_svg( 'page-header-left' ) ); ?>
			<div class="angled-bg angled-bg--middle">
			</div>
				<div class="container">
					<?php if ( 'skills' === $this_post_type || 'services' === $this_post_type || 'industries' === $this_post_type ) : ?>
						<p class="subheadline">

							<?php
							if ( 0 === $post->post_parent ) {
								?>
								<a href="/<?php echo esc_html( $post_type ); ?>">
									<?php echo esc_html( get_post_type_object( $post_type )->labels->singular_name ); ?>
								</a>
								<?php
							} else {
								?>
								<a href="<?php echo esc_url( get_permalink( $post->post_parent ) ); ?>">
									<?php echo esc_html( get_the_title( $post->post_parent ) ); ?>
								</a>
								<?php
							}
							?>
						</p>
					<?php endif; ?>
					<?php if ( ! is_home() ) : ?>
						<?php the_title( '<h1 class="entry-title text-center text-blue-dark">', '</h1>' ); ?>
					<?php else : ?>
						<h1 class="entry-title text-center text-blue-dark"><?php echo esc_html( get_the_title( get_option( 'page_for_posts', true ) ) ); ?></h1>
					<?php endif; ?>
				</div>
		<?php echo do_shortcode( rm_get_custom_svg( 'page-header-right' ) ); ?>
	</div>
</header><!-- .entry-header -->

<?php
/**
 * Template part for displaying the portfolio header.
 *
 * @package Raborn Media
 */

$hero_image = get_field( 'hero_image' );
?>

<div class="hero-image">
	<?php echo wp_get_attachment_image( $hero_image, 'project-hero' ); ?>
</div>
<header class="portfolio-header container">

	<?php the_title( '<h1 class="entry-title text-center text-blue-dark">', '</h1>' ); ?>

</header><!-- .entry-header -->

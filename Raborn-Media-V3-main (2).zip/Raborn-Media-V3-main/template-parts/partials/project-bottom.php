<?php
/**
 * Template part for displaying the bottom area of a project.
 *
 * @package Raborn Media
 */

$cta_title = get_field( 'project_cta_headline', 'options' );
$cta_link  = get_field( 'project_cta_link', 'options' );

?>

<section class="project-bottom">
	<div class="inner-top">
		<div class="angled-bg angled-bg--top-to-bottom">
		</div>
		<?php rm_related_projects(); ?>
	</div>
	<div class="inner-bottom">
		<div class="angled-bg angled-bg--bottom-to-top">
		</div>
		<div class="container">
			<div class="cta">
				<h2><?php echo esc_html( $cta_title ); ?></h2>
				<a href="https://calendly.com/gary-rabornmedia" target="_blank" rel="nofollower noopener" class="button bg-blue"><?php echo esc_html( $cta_link['title'] ); ?></a>
			</div>
		</div>
	</div>
	<?php echo do_shortcode( rm_get_custom_svg( 'project-bottom-left' ) ); ?>
	<?php echo do_shortcode( rm_get_custom_svg( 'project-bottom-right' ) ); ?>
	<?php echo do_shortcode( rm_get_custom_svg( 'circle-pattern' ) ); ?>
</section>

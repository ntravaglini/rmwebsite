<?php
/**
 * Template part for displaying the page header.
 *
 * @package Raborn Media
 */

$this_post_type = get_post_type();
?>

<header class="entry-header">
	<div class="inner-header">
		<?php echo do_shortcode( rm_get_custom_svg( 'page-header-left' ) ); ?>
			<div class="angled-bg angled-bg--middle">
			</div>
				<div class="container">
					<h1 class="entry-title text-center text-blue-dark">Our Team</h1>
				</div>
		<?php echo do_shortcode( rm_get_custom_svg( 'page-header-right' ) ); ?>
	</div>
</header><!-- .entry-header -->

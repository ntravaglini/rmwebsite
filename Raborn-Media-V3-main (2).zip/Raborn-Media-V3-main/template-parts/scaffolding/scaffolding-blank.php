<?php
/**
 * The template used for displaying X in the scaffolding library.
 *
 * @package Raborn Media
 */

?>

<section class="section-scaffolding">
	<h2 class="scaffolding-heading"><?php esc_html_e( 'X', 'rm' ); ?></h2>
</section>

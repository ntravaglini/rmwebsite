<?php
/**
 * Template Name: Portfolio
 *
 * Template Post Type: page, portfolio
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Raborn Media
 */

get_header(); ?>

	<main id="main" class="page-main">

		<?php
			get_template_part( 'template-parts/partials/page-header' );
		?>

		<?php
			get_template_part( 'template-parts/content-portfolio-filter' );
		?>

	</main><!-- #main -->

<?php get_footer(); ?>
